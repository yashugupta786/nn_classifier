from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import SGDClassifier
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import LinearSVC
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.multiclass import OneVsRestClassifier
X_train = [u'How much is the contribution towards Provident Fund?',
          u'I want to know about my Provident Fund deduction',
          u'What deductions are made towards Provident Fund?',
          u'What is the deduction for Provident Fund?',
          u'What amount goes into Provident fund?',

          u'What is Voluntary Provident Fund, how can I make additional contribution?',
          u'What is the process for Voluntary Provident Fund contribution?',
          u'Who do I contact in case I want to make Voluntary Contribution to the Provident Fund?',
          u'What is the process to apply for Voluntary contribution amount to my Provident Fund?',
          u'Tell me the steps to contribute additional sum to my Provident fund',

          u'Is my Provident Fund account managed by RPFC or Genpact?',
          u'Where is my Provident Fund contribution deposited?',
          u'Where is Provident Fund and FPF deposited?',
          u'Where is Family pension fund deposited?',
          u'where do we save our Provident Fund contribution?',

          u'How can I withdraw my Provident Fund?',
          u'How can I apply for my Provident fund amount?',
          u'What is the process to get Provident Fund amount?',
          u'What are the steps for Provident Fund amount withdrawal?',

          u'Can I withdraw  my Provident Fund under medical emergency?',
          u'Can I apply for Provident Fund loan for treatment of illness?',
          u'Please tell the process to apply for Provident Fund in order to get medical treatment',
          u'I want to know the Provident Fund withdrawal process in case of medical emergency.',
          u'What documents are required to apply for Provident Fund amount under medical exigency?',
          ]
y_train = [[1],[1],[1],[1],[1],[2],[2],[2],[2],[2],[3],[3],[3],[3],[3],[4],[4],[4],[4],[5],[5],[5],[5],[5]]
classifier = Pipeline([('vect', CountVectorizer(ngram_range=(1, 2), token_pattern=r'\b\w+\b', min_df=0,
                                                          stop_words='english', analyzer='word')),
                                 ('tfidf', TfidfTransformer()), ('clf',
                                                                 SGDClassifier(loss='modified_huber', alpha=1e-3,
                                                                               n_iter=500, random_state=42,
                                                                             shuffle=True)), ])
TEXT_CLASSIFIER=classifier.fit(X_train, y_train)


def fetch_interpreted_q(query):
    """
    this functions predicts the interpreted question for a given query
    :param query: a model and a label encorder for the model
    :return: a interpreted query class
    """
    #
    print(query)
    otherq = []
    scores = []
    pred = TEXT_CLASSIFIER.predict(query)
    otherpreds = TEXT_CLASSIFIER.predict_proba(query)[0]
    np.sum(otherpreds)
    maximum = otherpreds[pred[0]]
    # inter_q = LABEL_ENCODER_DATA.inverse_transform(pred)
    return pred,otherpreds,maximum


question = ""
while question != "exit()":
    print ("\n\n")
    question = input("Enter Sentence: ")

    query = [question]
    # print (question)
    print ("\n")

    inter_q,other_data,maximum = (fetch_interpreted_q(query))

    print (inter_q[0],other_data)
    print(maximum)

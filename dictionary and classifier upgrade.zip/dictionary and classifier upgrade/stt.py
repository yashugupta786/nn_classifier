from nltk.stem import SnowballStemmer

documents=[
          u'How much is the contribution towards Provident Fund?',
          u'I want to know about my Provident Fund deduction',
          u'What deduction are made towards Provident Fund?',
          u'What is the deduction for Provident Fund?',
          u'What amount goes into Provident fund?',

          u'What is Voluntary Provident Fund, how can I make additional contribution?',
          u'What is the process for Voluntary Provident Fund contribution?',
          u'Who do I contact in case I want to make Voluntary Contribution to the Provident Fund?',
          u'What is the process to apply for Voluntary contribution amount to my Provident Fund?',
          u'Tell me the steps to contribute additional sum to my Provident fund',

          u'Is my Provident Fund account managed by RPFC or Genpact?',
          u'Where is my Provident Fund contribution deposited?',
          u'Where is Provident Fund and FPF deposited?',
          u'Where is Family pension fund deposited?',
          u'where do we save our Provident Fund contribution words?',
    'I want to perform lemmatization on them to remove words which have the same meaning but are in different tenses']
import nltk
from nltk.stem.snowball import SnowballStemmer
stemmer = SnowballStemmer("english")




results=lambda doc: ([stemmer.stem(w) for w in documents])
print(results(documents))

# from stemming.porter2 import stem
lemma = nltk.WordNetLemmatizer()
output=[]
output1=[]
print(output)
results2 = [[lemma.lemmatize(word) for word in sentence.split(" ")] for sentence in documents]
for i in results2:
    output1.append(" ".join(i))
print(output1)
output1=[x.lower() for x in output1]
print(output1)
import logging
import re
from test_project.corpus_data import X_train ,y_train
from sklearn.linear_model import SGDClassifier
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.svm import LinearSVC
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.multiclass import OneVsRestClassifier
#-----------------------------
logger = logging.getLogger("Classifier")
logger.setLevel(logging.INFO)

handler = logging.StreamHandler()
handler.setLevel(logging.INFO)

formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

logger.addHandler(handler)
#--------------------------------------------------

classifier = Pipeline([('vect', CountVectorizer(ngram_range=(1, 2)
                                                        )),
                                 ('tfidf', TfidfTransformer()), ('clf',
                                                                 SGDClassifier(loss='modified_huber', alpha=1e-3,
                                                                               n_iter=1000, random_state=42,n_jobs=-1,
                                                                             shuffle=True)), ])
TEXT_CLASSIFIER=classifier.fit(X_train, y_train)

import math
def fetch_interpreted_q(query):
    """
    this functions predicts the interpreted question for a given query
    :param query: a model and a label encorder for the model
    :return: a interpreted query class
    """
    print(query)
    otherq = []
    scores = []
    pred = TEXT_CLASSIFIER.predict(query)

    print("check1",TEXT_CLASSIFIER.decision_function(query))
    value1 = TEXT_CLASSIFIER.decision_function(query)
    data = np.argmax(value1)
    print("decision function",data)
    print("clases associated",TEXT_CLASSIFIER.classes_)
    print("--------------------------------------------")
    print("predicted query label", pred)
    print("-------------------------------------------------")
    otherpreds = TEXT_CLASSIFIER.predict_proba(query)[0]
    otherpred = TEXT_CLASSIFIER.predict_proba(query)
    print("my oother pred",otherpreds)

    print("argmax score from other pred",np.argmax(otherpreds))

    print("predicted query label",pred[0])
    # i = 0
    # limit = 3
    # print("befor", len(otherpreds))
    # if (len(otherpreds) < 3):
    #     print("after", len(otherpreds))
    #     limit = len(otherpreds)
    # while i < limit:
    #     max_score = np.argmax(otherpreds)
    #     otherq.append(max_score)
    #     scores.append(otherpreds[max_score])
    #     otherpreds[max_score] = -1
    #     # otherpreds[max_score]=0.0000
    #     i += 1
    #     print("all scores",scores)
    #     print("max score",max_score)
    #     print("---------------")
    # logger.info("The Other top scores are ")
    # logger.info(scores)
    # otherpreds[pred[0]] = -1
    # print("maximum confidence score",maximum)
    # maximum = otherpreds[pred[0]]
    # inter_q = LABEL_ENCODER_DATA.inverse_transform(pred)
    return pred,otherpreds


question = ""
while question != "exit()":
    print ("\n\n")
    question = input("Enter Sentence: ")

    query = [question]
    # print (question)
    print ("\n")

    inter_q,other_data = (fetch_interpreted_q(query))

    print ("results",inter_q[0],other_data,"mine")


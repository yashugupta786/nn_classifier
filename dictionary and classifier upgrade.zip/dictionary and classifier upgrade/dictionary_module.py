import numpy as np

corpus = [
          "How do i change my password",
          "How do i alter my lun",
    "how do i delete my account",
    "how do i remove my fudi",

          ]

import json

import re
import string
import numpy as np

dict={
    'change':"#286",
    'alter':"#286",
    "remove":"#287",
    "delete":"#287"
}

new_list=[]
def replace_matched_items(word_list,dictq):
   for lst in word_list:
       # print(lst)
       splited_text=lst.split()

       for new_word in splited_text:
           if new_word in dictq:

               # print(new_word)
               new_list.append(re.sub(r'\b' + new_word + r'\b', str(dict[new_word]), lst))
   return new_list

my_Data=replace_matched_items(corpus,dict)
print(my_Data)